#!/usr/bin/env python3
"""
train_model.py
──────────────
Trains a Random Forest Classifier on combined clinical + AAC protein features
for early Alzheimer's risk classification (Low / Medium / High).

Input  : alzheimers_feature_dataset.xlsx  (AAC features + Label)
Output : model_compact.json               (embedded into index.html)
         training_report.txt              (detailed metrics report)

Usage:
    pip install scikit-learn pandas openpyxl numpy
    python train_model.py
"""

import pandas as pd
import numpy as np
import json
import os
import warnings
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, confusion_matrix, classification_report
)

warnings.filterwarnings("ignore")

# ─── HYPERPARAMETERS ─────────────────────────────────────────────────────────
CONFIG = {
    "n_estimators":      30,
    "max_depth":         10,
    "min_samples_leaf":  5,
    "test_size":         0.20,
    "random_state":      42,
    "risk_percentiles":  [33, 66],   # thresholds for Low/Medium/High split
}

FEATURE_DATASET = "alzheimers_feature_dataset.xlsx"
OUTPUT_JSON     = "model_compact.json"
REPORT_FILE     = "training_report.txt"


# ─── STEP 1: LOAD DATA ───────────────────────────────────────────────────────
def load_data(path: str):
    print(f"[1/6] Loading feature dataset: {path}")
    df = pd.read_excel(path)
    aac_cols = [c for c in df.columns if c.startswith("AAC_")]
    X_protein = df[aac_cols].values
    y_bin = df["Label"].values
    print(f"      {len(df)} samples | {len(aac_cols)} AAC features | Binary labels: {np.bincount(y_bin)}")
    return X_protein, y_bin, aac_cols


# ─── STEP 2: GENERATE SYNTHETIC CLINICAL FEATURES ────────────────────────────
def generate_clinical_features(y_bin: np.ndarray, random_state: int = 42):
    """
    Generate synthetic clinical features correlated with the binary Alzheimer label.
    In a real deployment, these would come from patient records.

    Features: Age, Glucose (mg/dL), Blood Pressure (mmHg),
              Memory Score (0-100), Cognitive Score (0-100), Sleep Quality (hrs)
    """
    print("[2/6] Generating synthetic clinical features (correlated with labels)...")
    np.random.seed(random_state)
    n = len(y_bin)

    age       = np.where(y_bin==1, np.random.normal(72,  8,  n), np.random.normal(62,  8,  n))
    glucose   = np.where(y_bin==1, np.random.normal(105, 20, n), np.random.normal(90,  15, n))
    bp        = np.where(y_bin==1, np.random.normal(135, 18, n), np.random.normal(120, 15, n))
    memory    = np.where(y_bin==1, np.random.normal(55,  15, n), np.random.normal(78,  12, n))
    cognitive = np.where(y_bin==1, np.random.normal(60,  15, n), np.random.normal(82,  10, n))
    sleep     = np.where(y_bin==1, np.random.normal(5.5, 1.2,n), np.random.normal(7.2, 1.0,n))

    X_clinical = np.column_stack([age, glucose, bp, memory, cognitive, sleep])
    print(f"      Generated 6 clinical features for {n} samples")
    return X_clinical


# ─── STEP 3: CREATE 3-CLASS RISK LABELS ─────────────────────────────────────
def create_multiclass_labels(y_bin, X_clinical, percentiles):
    """
    Derive Low(0) / Medium(1) / High(2) risk labels from a composite risk score.
    """
    print("[3/6] Creating 3-class risk labels (Low / Medium / High)...")
    age, glucose, bp, memory, cognitive, sleep = (X_clinical[:, i] for i in range(6))

    z = lambda x: (x - x.mean()) / x.std()
    combined_risk = z(age) + z(glucose) + z(bp) - z(memory) - z(cognitive) - z(sleep)

    thresholds = np.percentile(combined_risk, percentiles)
    y_multi = np.digitize(combined_risk, thresholds)
    counts = np.bincount(y_multi)
    print(f"      Low={counts[0]}, Medium={counts[1]}, High={counts[2]}")
    return y_multi


# ─── STEP 4: TRAIN RANDOM FOREST ─────────────────────────────────────────────
def train(X_all, y_multi, cfg):
    print("[4/6] Training Random Forest Classifier...")
    X_tr, X_te, y_tr, y_te = train_test_split(
        X_all, y_multi,
        test_size=cfg["test_size"],
        random_state=cfg["random_state"],
        stratify=y_multi
    )
    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr)
    X_te_s = scaler.transform(X_te)

    rf = RandomForestClassifier(
        n_estimators=cfg["n_estimators"],
        max_depth=cfg["max_depth"],
        min_samples_leaf=cfg["min_samples_leaf"],
        random_state=cfg["random_state"]
    )
    rf.fit(X_tr_s, y_tr)

    y_pred = rf.predict(X_te_s)
    metrics = {
        "accuracy":         round(float(accuracy_score(y_te, y_pred)),  4),
        "precision":        round(float(precision_score(y_te, y_pred, average="weighted")), 4),
        "recall":           round(float(recall_score(y_te, y_pred, average="weighted")),    4),
        "f1":               round(float(f1_score(y_te, y_pred, average="weighted")),        4),
        "confusion_matrix": confusion_matrix(y_te, y_pred).tolist(),
    }
    report = classification_report(y_te, y_pred, target_names=["Low", "Medium", "High"])

    print(f"      Accuracy : {metrics['accuracy']:.4f}")
    print(f"      Precision: {metrics['precision']:.4f}")
    print(f"      Recall   : {metrics['recall']:.4f}")
    print(f"      F1 Score : {metrics['f1']:.4f}")
    print(f"      Confusion Matrix:\n{np.array(metrics['confusion_matrix'])}")

    return rf, scaler, metrics, report, (X_tr_s, X_te_s, y_tr, y_te)


# ─── STEP 5: SERIALIZE MODEL ─────────────────────────────────────────────────
def export_tree_compact(tree):
    """Serialize a single DecisionTree to compact arrays."""
    t = tree.tree_
    return {
        "f":  t.feature.tolist(),
        "th": [round(x, 6) for x in t.threshold.tolist()],
        "l":  t.children_left.tolist(),
        "r":  t.children_right.tolist(),
        "v":  [list(map(int, row[0])) for row in t.value]
    }


def save_model_json(rf, scaler, metrics, aac_cols, output_path):
    print(f"[5/6] Serializing model to JSON: {output_path}")
    model_data = {
        "scaler_mean": [round(x, 8) for x in scaler.mean_.tolist()],
        "scaler_std":  [round(x, 8) for x in scaler.scale_.tolist()],
        "trees":       [export_tree_compact(est) for est in rf.estimators_],
        "n_classes":   3,
        "metrics":     metrics,
        "aac_cols":    aac_cols,
    }
    model_json = json.dumps(model_data, separators=(",", ":"))
    with open(output_path, "w") as f:
        f.write(model_json)
    print(f"      Saved {output_path} ({len(model_json)/1024:.1f} KB)")
    return model_json


# ─── STEP 6: SAVE TRAINING REPORT ────────────────────────────────────────────
def save_report(metrics, report, cfg, aac_cols, report_path):
    print(f"[6/6] Writing training report: {report_path}")
    cm = np.array(metrics["confusion_matrix"])
    with open(report_path, "w") as f:
        f.write("=" * 60 + "\n")
        f.write("  EARLY ALZHEIMER'S DETECTION – TRAINING REPORT\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Algorithm   : Random Forest Classifier\n")
        f.write(f"N Estimators: {cfg['n_estimators']}\n")
        f.write(f"Max Depth   : {cfg['max_depth']}\n")
        f.write(f"Min Samples : {cfg['min_samples_leaf']}\n")
        f.write(f"Test Split  : {cfg['test_size']*100:.0f}%\n\n")
        f.write("─" * 60 + "\n")
        f.write("PERFORMANCE METRICS\n")
        f.write("─" * 60 + "\n")
        f.write(f"Accuracy : {metrics['accuracy']:.4f} ({metrics['accuracy']*100:.2f}%)\n")
        f.write(f"Precision: {metrics['precision']:.4f}\n")
        f.write(f"Recall   : {metrics['recall']:.4f}\n")
        f.write(f"F1 Score : {metrics['f1']:.4f}\n\n")
        f.write("─" * 60 + "\n")
        f.write("CONFUSION MATRIX  [rows=Actual, cols=Predicted]\n")
        f.write("─" * 60 + "\n")
        f.write("              Pred-Low  Pred-Med  Pred-High\n")
        labels = ["Actual-Low", "Actual-Med", "Actual-High"]
        for i, row_label in enumerate(labels):
            f.write(f"{row_label:14s}  {cm[i][0]:8d}  {cm[i][1]:8d}  {cm[i][2]:9d}\n")
        f.write("\n")
        f.write("─" * 60 + "\n")
        f.write("CLASSIFICATION REPORT\n")
        f.write("─" * 60 + "\n")
        f.write(report + "\n")
        f.write("─" * 60 + "\n")
        f.write("FEATURES USED\n")
        f.write("─" * 60 + "\n")
        f.write("Clinical (6): Age, Glucose, BloodPressure, MemoryScore, CognitiveScore, SleepQuality\n")
        f.write(f"Protein ({len(aac_cols)}): {', '.join(aac_cols)}\n")
    print(f"      Report saved.")


# ─── MAIN ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not os.path.exists(FEATURE_DATASET):
        print(f"ERROR: {FEATURE_DATASET} not found.")
        print("Run feature_extraction.py first, or ensure the file is present.")
        exit(1)

    X_protein, y_bin, aac_cols = load_data(FEATURE_DATASET)
    X_clinical = generate_clinical_features(y_bin, CONFIG["random_state"])
    X_all = np.hstack([X_clinical, X_protein])
    y_multi = create_multiclass_labels(y_bin, X_clinical, CONFIG["risk_percentiles"])

    rf, scaler, metrics, report, splits = train(X_all, y_multi, CONFIG)
    save_model_json(rf, scaler, metrics, aac_cols, OUTPUT_JSON)
    save_report(metrics, report, CONFIG, aac_cols, REPORT_FILE)

    print("\n✅ Training complete!")
    print(f"   Model  → {OUTPUT_JSON}")
    print(f"   Report → {REPORT_FILE}")
    print()
    print("To embed the model into index.html:")
    print("  1. Open index.html in a text editor")
    print("  2. Find the line:  const MODEL = {...")
    print("  3. Replace the entire object with the contents of model_compact.json")
