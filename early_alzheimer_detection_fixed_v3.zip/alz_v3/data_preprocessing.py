#!/usr/bin/env python3
"""
data_preprocessing.py
──────────────────────
Performs exploratory data analysis (EDA) and preprocessing on both datasets.

Outputs:
  - eda_report.txt        : summary statistics and data quality report
  - eda_plots.png         : distribution plots (if matplotlib available)

Usage:
    pip install pandas openpyxl numpy matplotlib seaborn
    python data_preprocessing.py
"""

import pandas as pd
import numpy as np
import os
import warnings
warnings.filterwarnings("ignore")

FASTA_FILE   = "combined_fasta_dataset.xlsx"
FEATURE_FILE = "alzheimers_feature_dataset.xlsx"
AA_LIST      = list("ACDEFGHIKLMNPQRSTVWY")


# ─── LOAD DATASETS ────────────────────────────────────────────────────────────
def load_datasets():
    datasets = {}

    if os.path.exists(FEATURE_FILE):
        df_feat = pd.read_excel(FEATURE_FILE)
        datasets["features"] = df_feat
        print(f"✔ Loaded feature dataset : {df_feat.shape} ({FEATURE_FILE})")
    else:
        print(f"✘ Feature dataset not found: {FEATURE_FILE}")

    if os.path.exists(FASTA_FILE):
        df_fasta = pd.read_excel(FASTA_FILE)
        datasets["fasta"] = df_fasta
        print(f"✔ Loaded FASTA dataset   : {df_fasta.shape} ({FASTA_FILE})")
    else:
        print(f"✘ FASTA dataset not found: {FASTA_FILE}")

    return datasets


# ─── EDA: FEATURE DATASET ─────────────────────────────────────────────────────
def analyze_features(df: pd.DataFrame) -> str:
    aac_cols = [c for c in df.columns if c.startswith("AAC_")]
    report = []

    report.append("=" * 60)
    report.append("  FEATURE DATASET ANALYSIS")
    report.append("=" * 60)
    report.append(f"  Total samples     : {len(df)}")
    report.append(f"  Total columns     : {len(df.columns)}")
    report.append(f"  AAC features      : {len(aac_cols)}")
    report.append(f"  Other columns     : {[c for c in df.columns if c not in aac_cols]}")
    report.append("")

    # Label distribution
    label_counts = df["Label"].value_counts().sort_index()
    report.append("  Label Distribution:")
    for label, count in label_counts.items():
        pct = count / len(df) * 100
        name = "Alzheimer (1)" if label == 1 else "Non-Alzheimer (0)"
        report.append(f"    {name}: {count} ({pct:.1f}%)")
    report.append("")

    # Missing values
    missing = df.isnull().sum()
    n_missing = missing[missing > 0]
    if len(n_missing) == 0:
        report.append("  Missing Values    : None ✔")
    else:
        report.append(f"  Missing Values    : {len(n_missing)} columns with missing data")
        for col, cnt in n_missing.items():
            report.append(f"    {col}: {cnt} missing")
    report.append("")

    # AAC statistics
    report.append("  AAC Feature Statistics (mean across all samples):")
    aac_means = df[aac_cols].mean().sort_values(ascending=False)
    for col, val in aac_means.head(5).items():
        aa = col.replace("AAC_", "")
        report.append(f"    {aa}: {val:.4f} (most frequent)")
    for col, val in aac_means.tail(5).items():
        aa = col.replace("AAC_", "")
        report.append(f"    {aa}: {val:.4f} (least frequent)")
    report.append("")

    # Per-class AAC means
    report.append("  AAC Means by Label:")
    for label in sorted(df["Label"].unique()):
        subset = df[df["Label"] == label][aac_cols].mean()
        top3 = subset.nlargest(3)
        name = "Alzheimer" if label == 1 else "Non-Alzheimer"
        top_str = ", ".join(f"{c.replace('AAC_','')}={v:.3f}" for c, v in top3.items())
        report.append(f"    {name}: top3 = {top_str}")
    report.append("")

    # Value ranges
    report.append("  AAC Value Range Check:")
    all_ok = True
    for col in aac_cols:
        mn, mx = df[col].min(), df[col].max()
        if mn < 0 or mx > 1:
            report.append(f"    ⚠ {col}: [{mn:.4f}, {mx:.4f}] — out of [0,1] range")
            all_ok = False
    if all_ok:
        report.append("    All AAC values in valid range [0, 1] ✔")

    return "\n".join(report)


# ─── EDA: FASTA DATASET ───────────────────────────────────────────────────────
def analyze_fasta(df: pd.DataFrame) -> str:
    report = []

    report.append("\n" + "=" * 60)
    report.append("  FASTA DATASET ANALYSIS")
    report.append("=" * 60)
    report.append(f"  Total sequences   : {len(df)}")
    report.append(f"  Columns           : {df.columns.tolist()}")
    report.append("")

    # Sequence lengths
    df["seq_len"] = df["Protein_Sequence"].astype(str).apply(
        lambda s: len("".join(c for c in s.upper() if c in AA_LIST))
    )
    report.append("  Sequence Length Statistics:")
    report.append(f"    Min    : {df['seq_len'].min()}")
    report.append(f"    Max    : {df['seq_len'].max()}")
    report.append(f"    Mean   : {df['seq_len'].mean():.1f}")
    report.append(f"    Median : {df['seq_len'].median():.1f}")
    report.append("")

    # Label distribution
    label_counts = df["Label"].value_counts().sort_index()
    report.append("  Label Distribution:")
    for label, count in label_counts.items():
        pct = count / len(df) * 100
        name = "Alzheimer (1)" if label == 1 else "Non-Alzheimer (0)"
        report.append(f"    {name}: {count} ({pct:.1f}%)")
    report.append("")

    # Short sequences check
    short = df[df["seq_len"] < 10]
    report.append(f"  Very Short Sequences (<10 AA): {len(short)}")
    if len(short) > 0:
        report.append("  ⚠ These may produce unreliable AAC features.")

    return "\n".join(report)


# ─── PREPROCESS: CLINICAL FEATURES ───────────────────────────────────────────
def describe_clinical_features():
    """
    Documents the expected clinical feature ranges for validation.
    """
    features = {
        "Age":            (40, 100, "years",   "Patient age"),
        "Glucose":        (50, 300, "mg/dL",   "Fasting blood glucose"),
        "BloodPressure":  (60, 220, "mmHg",    "Systolic blood pressure"),
        "MemoryScore":    (0,  100, "score",   "Memory assessment (higher = better)"),
        "CognitiveScore": (0,  100, "score",   "Cognitive assessment (MMSE/MoCA)"),
        "SleepQuality":   (2,  12,  "hrs/day", "Average nightly sleep duration"),
    }

    report = ["\n" + "="*60, "  CLINICAL FEATURE SPECIFICATIONS", "="*60]
    for name, (lo, hi, unit, desc) in features.items():
        report.append(f"  {name:18s}: [{lo:4}, {hi:4}] {unit:8s} — {desc}")
    return "\n".join(report)


# ─── GENERATE PLOTS ───────────────────────────────────────────────────────────
def generate_eda_plots(df_feat: pd.DataFrame):
    try:
        import matplotlib.pyplot as plt
        import seaborn as sns
    except ImportError:
        print("  (matplotlib/seaborn not installed – skipping EDA plots)")
        return

    aac_cols = [c for c in df_feat.columns if c.startswith("AAC_")]
    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    fig.suptitle("Alzheimer's Feature Dataset – EDA", fontsize=14, fontweight="bold", y=1.01)

    # 1. Label distribution
    ax = axes[0, 0]
    counts = df_feat["Label"].value_counts().sort_index()
    ax.bar(["Non-Alzheimer (0)", "Alzheimer (1)"], counts.values,
           color=["#0e9f6e", "#e02424"], edgecolor="white", linewidth=0.8)
    ax.set_title("Label Distribution")
    ax.set_ylabel("Count")
    for i, v in enumerate(counts.values):
        ax.text(i, v + 5, str(v), ha="center", fontsize=11, fontweight="bold")
    ax.spines[["top","right"]].set_visible(False)

    # 2. Mean AAC by label
    ax = axes[0, 1]
    mean0 = df_feat[df_feat["Label"]==0][aac_cols].mean()
    mean1 = df_feat[df_feat["Label"]==1][aac_cols].mean()
    x = range(len(aac_cols))
    aa_names = [c.replace("AAC_", "") for c in aac_cols]
    ax.bar([i - 0.2 for i in x], mean0, width=0.35, label="Non-Alzheimer", color="#0e9f6e", alpha=0.8)
    ax.bar([i + 0.2 for i in x], mean1, width=0.35, label="Alzheimer",     color="#e02424", alpha=0.8)
    ax.set_xticks(list(x))
    ax.set_xticklabels(aa_names, fontsize=7)
    ax.set_title("Mean AAC by Class")
    ax.set_ylabel("Mean Frequency")
    ax.legend(fontsize=8)
    ax.spines[["top","right"]].set_visible(False)

    # 3. AAC heatmap
    ax = axes[1, 0]
    sample = df_feat[aac_cols].sample(min(50, len(df_feat)), random_state=42)
    sns.heatmap(sample.T, ax=ax, cmap="YlOrRd", yticklabels=aa_names,
                xticklabels=False, cbar_kws={"shrink": 0.7})
    ax.set_title("AAC Feature Heatmap (50 samples)")
    ax.set_xlabel("Samples")

    # 4. Correlation of top AAC features
    ax = axes[1, 1]
    corr = df_feat[aac_cols + ["Label"]].corr()["Label"].drop("Label").sort_values()
    colors = ["#e02424" if v > 0 else "#0e9f6e" for v in corr.values]
    ax.barh(corr.index.str.replace("AAC_",""), corr.values, color=colors, edgecolor="white")
    ax.set_title("AAC Feature Correlation with Label")
    ax.set_xlabel("Pearson r")
    ax.axvline(0, color="gray", linewidth=0.8, linestyle="--")
    ax.spines[["top","right"]].set_visible(False)

    plt.tight_layout()
    plt.savefig("eda_plots.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("  Saved: eda_plots.png")


# ─── MAIN ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Early Alzheimer's Detection – Data Preprocessing & EDA")
    print("="*60)

    datasets = load_datasets()
    report_lines = []

    if "features" in datasets:
        feat_report = analyze_features(datasets["features"])
        print(feat_report)
        report_lines.append(feat_report)

    if "fasta" in datasets:
        fasta_report = analyze_fasta(datasets["fasta"])
        print(fasta_report)
        report_lines.append(fasta_report)

    clinical_report = describe_clinical_features()
    print(clinical_report)
    report_lines.append(clinical_report)

    # Save report
    with open("eda_report.txt", "w") as f:
        f.write("\n".join(report_lines))
    print("\n  Saved: eda_report.txt")

    # Generate plots
    if "features" in datasets:
        print("\nGenerating EDA plots...")
        generate_eda_plots(datasets["features"])

    print("\n✅ Preprocessing complete!")
