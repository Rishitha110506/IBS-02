#!/usr/bin/env python3
"""
utils.py
────────
Shared utility functions for the Early Alzheimer's Detection project.

Imported by: feature_extraction.py, train_model.py, evaluate_model.py
"""

import json
import numpy as np
import os

# ─── CONSTANTS ────────────────────────────────────────────────────────────────
AA_LIST       = list("ACDEFGHIKLMNPQRSTVWY")  # 20 standard amino acids
RISK_LABELS   = {0: "LOW", 1: "MEDIUM", 2: "HIGH"}
RISK_CLASSES  = ["Low", "Medium", "High"]
CLINICAL_FEATURES = ["Age", "Glucose", "BloodPressure", "MemoryScore", "CognitiveScore", "SleepQuality"]
CLINICAL_RANGES = {
    "Age":            (40,  100),
    "Glucose":        (50,  300),
    "BloodPressure":  (60,  220),
    "MemoryScore":    (0,   100),
    "CognitiveScore": (0,   100),
    "SleepQuality":   (2,   12),
}

# ─── AAC EXTRACTION ───────────────────────────────────────────────────────────
def fasta_to_aac(fasta_text: str) -> list | None:
    """
    Parse a FASTA-format string and return 20 AAC feature values.

    Parameters
    ----------
    fasta_text : str
        FASTA text, optionally with header lines (starting with '>').

    Returns
    -------
    list of 20 floats, or None if the sequence is empty/invalid.
    """
    lines = fasta_text.strip().split("\n")
    seq = ""
    for line in lines:
        if not line.startswith(">"):
            seq += line.strip().upper()
    seq_clean = "".join(c for c in seq if c in AA_LIST)
    if not seq_clean:
        return None
    total = len(seq_clean)
    return [seq_clean.count(aa) / total for aa in AA_LIST]


def sequence_stats(sequence: str) -> dict:
    """Return basic stats about a protein sequence."""
    seq = "".join(c for c in sequence.upper() if c in AA_LIST)
    if not seq:
        return {"length": 0, "valid": False}
    counts = {aa: seq.count(aa) for aa in AA_LIST}
    top3 = sorted(counts.items(), key=lambda x: -x[1])[:3]
    return {
        "length": len(seq),
        "valid": True,
        "top3_amino_acids": {aa: round(cnt/len(seq), 4) for aa, cnt in top3},
        "unique_amino_acids": sum(1 for v in counts.values() if v > 0),
    }


# ─── RANDOM FOREST INFERENCE (JS-equivalent in Python) ───────────────────────
def load_model(path: str = "model_compact.json") -> dict:
    """Load the serialized model JSON."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Model file not found: {path}")
    with open(path) as f:
        return json.load(f)


def _scale(features: list, mean: list, std: list) -> list:
    return [(v - mean[i]) / std[i] for i, v in enumerate(features)]


def _predict_tree(tree: dict, x: list) -> list:
    """Traverse a single decision tree and return class probabilities."""
    node = 0
    while True:
        # sklearn serializes leaf nodes with feature index = -2
        # Correct leaf check: tree["f"][node] == -2
        if tree["f"][node] == -2:          # leaf node
            v = tree["v"][node]
            s = sum(v)
            return [vi / s for vi in v] if s > 0 else [1/3, 1/3, 1/3]
        if x[tree["f"][node]] <= tree["th"][node]:
            node = tree["l"][node]
        else:
            node = tree["r"][node]


def predict(model: dict, features: list) -> dict:
    """
    Run Random Forest prediction.

    Parameters
    ----------
    model    : loaded model dict from load_model()
    features : list of 26 floats [6 clinical + 20 AAC]

    Returns
    -------
    dict with keys:
        'prediction'  : int 0=Low, 1=Medium, 2=High
        'label'       : str "LOW" / "MEDIUM" / "HIGH"
        'probabilities': {'low': float, 'medium': float, 'high': float}
    """
    x = _scale(features, model["scaler_mean"], model["scaler_std"])
    probs = [0.0, 0.0, 0.0]
    for tree in model["trees"]:
        p = _predict_tree(tree, x)
        for c in range(3):
            probs[c] += p[c]
    n = len(model["trees"])
    probs = [p / n for p in probs]
    pred = int(np.argmax(probs))
    return {
        "prediction": pred,
        "label": RISK_LABELS[pred],
        "probabilities": {
            "low":    round(probs[0], 4),
            "medium": round(probs[1], 4),
            "high":   round(probs[2], 4),
        }
    }


# ─── INPUT VALIDATION ─────────────────────────────────────────────────────────
def validate_clinical(age, glucose, bp, memory, cognitive, sleep) -> list:
    """
    Validate clinical input values against expected ranges.
    Returns list of error strings (empty list = all valid).
    """
    values = {
        "Age": age, "Glucose": glucose, "BloodPressure": bp,
        "MemoryScore": memory, "CognitiveScore": cognitive, "SleepQuality": sleep
    }
    errors = []
    for name, val in values.items():
        lo, hi = CLINICAL_RANGES[name]
        try:
            v = float(val)
            if v < lo or v > hi:
                errors.append(f"{name} must be between {lo} and {hi}.")
        except (TypeError, ValueError):
            errors.append(f"{name} must be a valid number.")
    return errors


# ─── PRECAUTIONS ─────────────────────────────────────────────────────────────
PRECAUTIONS = {
    "low": [
        "Continue regular physical activity and a balanced diet.",
        "Keep up social engagement and mental stimulation.",
        "Schedule routine annual health check-ups.",
        "Monitor blood pressure and blood sugar as part of preventive care.",
        "Maintain good sleep habits (7–8 hours per night).",
    ],
    "medium": [
        "Schedule a comprehensive neurological evaluation.",
        "Adopt a Mediterranean or MIND diet.",
        "Engage in aerobic exercise for at least 150 minutes per week.",
        "Monitor blood pressure, blood sugar, and cholesterol regularly.",
        "Practice cognitive stimulation activities: puzzles, reading, learning.",
        "Improve sleep hygiene to achieve 7–8 hours nightly.",
        "Reduce alcohol consumption and quit smoking if applicable.",
        "Manage stress through mindfulness or meditation.",
        "Stay socially active and connected.",
        "Consider genetic counseling and biomarker testing.",
    ],
    "high": [
        "Seek immediate consultation with a neurologist or dementia specialist.",
        "Undergo comprehensive neuropsychological testing and brain imaging.",
        "Discuss potential disease-modifying therapies with your doctor.",
        "Put legal and financial plans in place (power of attorney, advance directives).",
        "Enroll in a memory care monitoring program.",
        "Consider occupational therapy to maintain daily functioning.",
        "Evaluate home safety: remove fall hazards, install safety locks.",
        "Review all current medications for any that may worsen cognition.",
        "Explore caregiver support services and respite care options.",
        "Join a clinical trial — ClinicalTrials.gov lists current studies.",
        "Maintain a structured daily routine to reduce confusion.",
        "Use a CPAP if sleep apnea is present.",
    ]
}


def get_precautions(level: int) -> list:
    """Return precaution list for a given risk level (0=low, 1=medium, 2=high)."""
    key = ["low", "medium", "high"][level]
    return PRECAUTIONS[key]


# ─── QUICK TEST ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("utils.py self-test")

    # AAC test
    fasta = ">test\nACDEFGHIKLMNPQRSTVWY"
    aac = fasta_to_aac(fasta)
    assert aac is not None and len(aac) == 20
    assert abs(sum(aac) - 1.0) < 1e-9
    print(f"  fasta_to_aac: OK  (sum={sum(aac):.6f})")

    # Validation test
    errs = validate_clinical(75, 100, 130, 60, 70, 7.0)
    assert errs == [], f"Expected no errors, got: {errs}"
    errs = validate_clinical(200, 50, 130, 60, 70, 7.0)
    assert len(errs) == 1
    print(f"  validate_clinical: OK")

    # Sequence stats
    stats = sequence_stats("ACDEFGHIKLMNPQRSTVWY")
    assert stats["length"] == 20 and stats["unique_amino_acids"] == 20
    print(f"  sequence_stats: OK  ({stats})")

    print("All tests passed ✔")
