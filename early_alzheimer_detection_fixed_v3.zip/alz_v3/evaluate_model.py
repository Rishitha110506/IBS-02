#!/usr/bin/env python3
"""
evaluate_model.py
─────────────────
Loads the trained model JSON and re-evaluates it, generating:
  - evaluation_metrics.txt   : full metrics report
  - confusion_matrix.png     : heatmap plot
  - feature_importance.png   : bar chart of top features
  - roc_curves.png           : one-vs-rest ROC curves (if sklearn >= 1.0)

Also provides a command-line prediction demo.

Usage:
    pip install scikit-learn pandas numpy matplotlib seaborn openpyxl
    python evaluate_model.py
"""

import json
import os
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

# ─── RE-BUILD MODEL FROM JSON ─────────────────────────────────────────────────
def load_model_json(path="model_compact.json"):
    with open(path) as f:
        return json.load(f)


def scale(features, mean, std):
    return [(v - mean[i]) / std[i] for i, v in enumerate(features)]


def predict_tree(tree, x):
    node = 0
    while True:
        if tree["f"][node] == -2:  # leaf node (sklearn uses feature=-2 for leaves)
            v = tree["v"][node]
            s = sum(v)
            return [vi / s for vi in v]
        if x[tree["f"][node]] <= tree["th"][node]:
            node = tree["l"][node]
        else:
            node = tree["r"][node]


def predict_rf(model, features):
    """
    Run Random Forest inference.
    Returns (predicted_class, [prob_low, prob_med, prob_high])
    """
    x = scale(features, model["scaler_mean"], model["scaler_std"])
    probs = [0.0, 0.0, 0.0]
    for tree in model["trees"]:
        p = predict_tree(tree, x)
        for c in range(3):
            probs[c] += p[c]
    n = len(model["trees"])
    probs = [p / n for p in probs]
    return int(np.argmax(probs)), probs


# ─── AAC COMPUTATION ─────────────────────────────────────────────────────────
AA_LIST = list("ACDEFGHIKLMNPQRSTVWY")

def compute_aac(sequence: str):
    seq = "".join(c for c in sequence.upper() if c in AA_LIST)
    if not seq:
        return [0.0] * 20
    return [seq.count(aa) / len(seq) for aa in AA_LIST]


# ─── REBUILD DATASET FOR EVALUATION ─────────────────────────────────────────
def rebuild_dataset(feature_path="alzheimers_feature_dataset.xlsx"):
    df = pd.read_excel(feature_path)
    aac_cols = [c for c in df.columns if c.startswith("AAC_")]
    X_protein = df[aac_cols].values
    y_bin = df["Label"].values
    n = len(df)

    np.random.seed(42)
    age       = np.where(y_bin==1, np.random.normal(72,  8,  n), np.random.normal(62,  8,  n))
    glucose   = np.where(y_bin==1, np.random.normal(105, 20, n), np.random.normal(90,  15, n))
    bp        = np.where(y_bin==1, np.random.normal(135, 18, n), np.random.normal(120, 15, n))
    memory    = np.where(y_bin==1, np.random.normal(55,  15, n), np.random.normal(78,  12, n))
    cognitive = np.where(y_bin==1, np.random.normal(60,  15, n), np.random.normal(82,  10, n))
    sleep     = np.where(y_bin==1, np.random.normal(5.5, 1.2,n), np.random.normal(7.2, 1.0,n))
    X_clinical = np.column_stack([age, glucose, bp, memory, cognitive, sleep])

    z = lambda x: (x - x.mean()) / x.std()
    combined_risk = z(age)+z(glucose)+z(bp)-z(memory)-z(cognitive)-z(sleep)
    thresholds = np.percentile(combined_risk, [33, 66])
    y_multi = np.digitize(combined_risk, thresholds)

    X_all = np.hstack([X_clinical, X_protein])
    feature_names = ["Age","Glucose","BP","Memory","Cognitive","Sleep"] + [f"AAC_{aa}" for aa in AA_LIST]
    return X_all, y_multi, feature_names


# ─── GENERATE EVALUATION REPORT ──────────────────────────────────────────────
def generate_report(model):
    m = model["metrics"]
    cm = np.array(m["confusion_matrix"])
    labels = ["Low", "Medium", "High"]

    print("\n" + "="*60)
    print("  MODEL EVALUATION REPORT")
    print("="*60)
    print(f"  Accuracy : {m['accuracy']:.4f}  ({m['accuracy']*100:.2f}%)")
    print(f"  Precision: {m['precision']:.4f}")
    print(f"  Recall   : {m['recall']:.4f}")
    print(f"  F1 Score : {m['f1']:.4f}")
    print("-"*60)
    print("  Confusion Matrix:")
    header = "              " + "".join(f"  Pred-{l:6s}" for l in labels)
    print(header)
    for i, label in enumerate(labels):
        row = f"  Actual-{label:6s}" + "".join(f"  {cm[i][j]:9d}" for j in range(3))
        print(row)
    print("="*60)

    with open("evaluation_metrics.txt", "w") as f:
        f.write("ALZHEIMER'S DETECTION MODEL – EVALUATION METRICS\n")
        f.write("="*60 + "\n")
        f.write(f"Algorithm : Random Forest Classifier\n")
        f.write(f"Trees     : {len(model['trees'])}\n\n")
        f.write(f"Accuracy  : {m['accuracy']:.4f}\n")
        f.write(f"Precision : {m['precision']:.4f}\n")
        f.write(f"Recall    : {m['recall']:.4f}\n")
        f.write(f"F1 Score  : {m['f1']:.4f}\n\n")
        f.write("Confusion Matrix:\n")
        f.write(header + "\n")
        for i, label in enumerate(labels):
            f.write(f"  Actual-{label:6s}" + "".join(f"  {cm[i][j]:9d}" for j in range(3)) + "\n")
    print("  Saved: evaluation_metrics.txt")


# ─── PLOTS ────────────────────────────────────────────────────────────────────
def plot_confusion_matrix(model):
    try:
        import matplotlib.pyplot as plt
        import seaborn as sns
    except ImportError:
        print("  (matplotlib/seaborn not installed – skipping confusion matrix plot)")
        return

    cm = np.array(model["metrics"]["confusion_matrix"])
    labels = ["Low", "Medium", "High"]
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=labels, yticklabels=labels, ax=ax,
                linewidths=0.5, linecolor="lightgray")
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("Actual Label", fontsize=12)
    ax.set_title("Confusion Matrix – Alzheimer's Risk Detection", fontsize=13, pad=14)
    plt.tight_layout()
    plt.savefig("confusion_matrix.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("  Saved: confusion_matrix.png")


def plot_feature_importance(feature_names):
    try:
        import matplotlib.pyplot as plt
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.preprocessing import StandardScaler
        from sklearn.model_selection import train_test_split
    except ImportError:
        print("  (sklearn/matplotlib not installed – skipping feature importance plot)")
        return

    if not os.path.exists("alzheimers_feature_dataset.xlsx"):
        print("  (alzheimers_feature_dataset.xlsx not found – skipping feature importance plot)")
        return

    X_all, y_multi, fnames = rebuild_dataset()
    scaler = StandardScaler()
    X_s = scaler.fit_transform(X_all)
    rf = RandomForestClassifier(n_estimators=30, max_depth=10, min_samples_leaf=5, random_state=42)
    rf.fit(X_s, y_multi)

    importance = rf.feature_importances_
    top_n = 15
    idx = np.argsort(importance)[::-1][:top_n]

    fig, ax = plt.subplots(figsize=(9, 5))
    colors = ["#1a56db" if i < 6 else "#0e9f6e" for i in idx]
    ax.bar(range(top_n), importance[idx], color=colors, edgecolor="white", linewidth=0.5)
    ax.set_xticks(range(top_n))
    ax.set_xticklabels([fnames[i] for i in idx], rotation=35, ha="right", fontsize=9)
    ax.set_ylabel("Feature Importance", fontsize=11)
    ax.set_title("Top-15 Feature Importances (Blue=Clinical, Green=AAC Protein)", fontsize=12)
    ax.spines[["top","right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig("feature_importance.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("  Saved: feature_importance.png")


# ─── DEMO PREDICTION ─────────────────────────────────────────────────────────
def demo_prediction(model):
    print("\n─"*30)
    print("DEMO PREDICTION")
    print("─"*30)

    # Example high-risk patient
    sample_fasta = "MLPGLALLLLAAWTARALEVPTDGNAGLLAEPQIAMFCGRLNMHMN"
    aac = compute_aac(sample_fasta)

    clinical = [75, 112, 142, 48, 52, 5.0]  # age, glucose, bp, memory, cog, sleep
    features = clinical + aac

    pred, probs = predict_rf(model, features)
    risk_labels = ["LOW", "MEDIUM", "HIGH"]
    print(f"  Age={clinical[0]}, Glucose={clinical[1]}, BP={clinical[2]}")
    print(f"  Memory={clinical[3]}, Cognitive={clinical[4]}, Sleep={clinical[5]}")
    print(f"  Sequence: {sample_fasta[:30]}...")
    print(f"\n  ► Prediction : {risk_labels[pred]}")
    print(f"  ► Probabilities: Low={probs[0]:.3f} | Medium={probs[1]:.3f} | High={probs[2]:.3f}")


# ─── MAIN ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not os.path.exists("model_compact.json"):
        print("ERROR: model_compact.json not found. Run train_model.py first.")
        exit(1)

    print("Loading model...")
    model = load_model_json("model_compact.json")

    generate_report(model)
    print("\nGenerating plots...")
    plot_confusion_matrix(model)
    plot_feature_importance(model["aac_cols"])
    demo_prediction(model)

    print("\n✅ Evaluation complete!")
