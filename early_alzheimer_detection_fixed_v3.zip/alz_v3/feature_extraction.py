#!/usr/bin/env python3
"""
feature_extraction.py
─────────────────────
Extracts Amino Acid Composition (AAC) features from protein FASTA sequences.

Input  : combined_fasta_dataset.xlsx  (columns: Sequence_ID, Protein_Sequence, Label)
Output : alzheimers_feature_dataset.xlsx  (20 AAC features + Sequence_ID + Label)

Usage:
    pip install pandas openpyxl biopython
    python feature_extraction.py
"""

import pandas as pd
import numpy as np
import os

# ─── STANDARD AMINO ACIDS ────────────────────────────────────────────────────
AA_LIST = list("ACDEFGHIKLMNPQRSTVWY")  # 20 standard amino acids


def compute_aac(sequence: str) -> dict:
    """
    Compute Amino Acid Composition (AAC) for a protein sequence.
    AAC[aa] = count(aa) / total_length

    Parameters
    ----------
    sequence : str
        Raw protein sequence string (case-insensitive).

    Returns
    -------
    dict
        Keys: 'AAC_A', 'AAC_C', ... 'AAC_Y'  (20 features)
        Values: float frequency in [0, 1]
    """
    seq = sequence.upper().strip()
    # Keep only standard amino acids
    seq_clean = "".join(c for c in seq if c in AA_LIST)
    total = len(seq_clean)

    aac = {}
    if total == 0:
        for aa in AA_LIST:
            aac[f"AAC_{aa}"] = 0.0
    else:
        for aa in AA_LIST:
            aac[f"AAC_{aa}"] = seq_clean.count(aa) / total
    return aac


def parse_fasta_text(fasta_text: str) -> str:
    """
    Extract the sequence portion from a FASTA-formatted string.
    Handles multi-line FASTA (ignores header lines starting with '>').
    """
    lines = fasta_text.strip().split("\n")
    seq = ""
    for line in lines:
        if not line.startswith(">"):
            seq += line.strip()
    return seq


def extract_features_from_excel(input_path: str, output_path: str):
    """
    Read FASTA sequences from Excel, compute AAC features, save to Excel.

    Parameters
    ----------
    input_path  : path to combined_fasta_dataset.xlsx
    output_path : path to write alzheimers_feature_dataset.xlsx
    """
    print(f"[1/4] Loading FASTA dataset from: {input_path}")
    df = pd.read_excel(input_path)
    print(f"      Loaded {len(df)} sequences | Columns: {df.columns.tolist()}")

    required = {"Sequence_ID", "Protein_Sequence", "Label"}
    if not required.issubset(df.columns):
        raise ValueError(f"Expected columns {required}, got {set(df.columns)}")

    print("[2/4] Computing AAC features...")
    aac_records = []
    skipped = 0
    for idx, row in df.iterrows():
        seq = str(row["Protein_Sequence"])
        aac = compute_aac(seq)
        if all(v == 0 for v in aac.values()):
            skipped += 1
        aac_records.append(aac)

    aac_df = pd.DataFrame(aac_records)
    print(f"      Computed {len(aac_df.columns)} AAC features | Skipped (empty): {skipped}")

    print("[3/4] Assembling output dataframe...")
    out_df = pd.concat([
        aac_df,
        df[["Sequence_ID", "Label"]].reset_index(drop=True)
    ], axis=1)

    print(f"[4/4] Saving to: {output_path}")
    out_df.to_excel(output_path, index=False)
    print(f"      Done. Shape: {out_df.shape}")
    print(f"      Label distribution: {out_df['Label'].value_counts().to_dict()}")
    return out_df


# ─── STANDALONE USAGE ────────────────────────────────────────────────────────
if __name__ == "__main__":
    INPUT  = "combined_fasta_dataset.xlsx"
    OUTPUT = "alzheimers_feature_dataset.xlsx"

    if not os.path.exists(INPUT):
        print(f"ERROR: Input file not found: {INPUT}")
        print("Please place combined_fasta_dataset.xlsx in the same directory.")
    else:
        df = extract_features_from_excel(INPUT, OUTPUT)
        print("\nSample output (first 3 rows):")
        print(df.head(3).to_string())


# ─── UNIT TEST ───────────────────────────────────────────────────────────────
def _test():
    seq = "AACDEFGHIKLMNPQRSTVWY"  # one of each standard AA
    aac = compute_aac(seq)
    assert abs(sum(aac.values()) - 1.0) < 1e-9, "AAC values must sum to 1"
    assert all(k.startswith("AAC_") for k in aac), "Keys must start with AAC_"
    print("All unit tests passed.")

if __name__ == "__main__":
    _test()
