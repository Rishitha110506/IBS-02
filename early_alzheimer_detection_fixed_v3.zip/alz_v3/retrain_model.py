#!/usr/bin/env python3
"""
retrain_model.py
Re-trains the Random Forest model and regenerates the embedded model JSON.
Run this script to update the model with new data or parameters.

Usage:
    pip install scikit-learn pandas openpyxl numpy
    python retrain_model.py

Then replace the MODEL = ... block in index.html with the contents of model_compact.json
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import json
import warnings
warnings.filterwarnings("ignore")

# ─── CONFIGURATION ────────────────────────────────────────────────────────────
FEATURE_DATASET = "alzheimers_feature_dataset.xlsx"
FASTA_DATASET   = "combined_fasta_dataset.xlsx"
OUTPUT_JSON     = "model_compact.json"
N_TREES         = 30
MAX_DEPTH       = 10
MIN_SAMPLES_LEAF= 5
TEST_SIZE       = 0.20
RANDOM_STATE    = 42
# ──────────────────────────────────────────────────────────────────────────────

print("[1/6] Loading datasets...")
df_feat = pd.read_excel(FEATURE_DATASET)
aac_cols = [c for c in df_feat.columns if c.startswith("AAC_")]
X_protein = df_feat[aac_cols].values
y_bin = df_feat["Label"].values
n = len(df_feat)
print(f"      Loaded {n} samples, {len(aac_cols)} AAC features")

print("[2/6] Generating synthetic clinical features correlated with labels...")
np.random.seed(RANDOM_STATE)
age      = np.where(y_bin==1, np.random.normal(72, 8, n), np.random.normal(62, 8, n))
glucose  = np.where(y_bin==1, np.random.normal(105,20, n), np.random.normal(90,15, n))
bp       = np.where(y_bin==1, np.random.normal(135,18, n), np.random.normal(120,15, n))
memory   = np.where(y_bin==1, np.random.normal(55, 15, n), np.random.normal(78,12, n))
cognitive= np.where(y_bin==1, np.random.normal(60, 15, n), np.random.normal(82,10, n))
sleep    = np.where(y_bin==1, np.random.normal(5.5,1.2,n), np.random.normal(7.2,1.0,n))
X_clinical = np.column_stack([age, glucose, bp, memory, cognitive, sleep])
X_all = np.hstack([X_clinical, X_protein])

print("[3/6] Creating 3-class risk labels (Low / Medium / High)...")
combined_risk = (
    (age      - age.mean())      / age.std() +
    (glucose  - glucose.mean())  / glucose.std() +
    (bp       - bp.mean())       / bp.std() -
    (memory   - memory.mean())   / memory.std() -
    (cognitive- cognitive.mean())/ cognitive.std() -
    (sleep    - sleep.mean())    / sleep.std()
)
percentiles = np.percentile(combined_risk, [33, 66])
y_multi = np.digitize(combined_risk, percentiles)
counts = np.bincount(y_multi)
print(f"      Low={counts[0]}, Medium={counts[1]}, High={counts[2]}")

print("[4/6] Training Random Forest...")
X_train, X_test, y_train, y_test = train_test_split(
    X_all, y_multi, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y_multi)
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)
rf = RandomForestClassifier(
    n_estimators=N_TREES, max_depth=MAX_DEPTH,
    min_samples_leaf=MIN_SAMPLES_LEAF, random_state=RANDOM_STATE)
rf.fit(X_train_s, y_train)
y_pred = rf.predict(X_test_s)

acc  = float(accuracy_score(y_test, y_pred))
prec = float(precision_score(y_test, y_pred, average="weighted"))
rec  = float(recall_score(y_test, y_pred, average="weighted"))
f1   = float(f1_score(y_test, y_pred, average="weighted"))
cm   = confusion_matrix(y_test, y_pred).tolist()

print(f"      Accuracy : {acc:.4f}")
print(f"      Precision: {prec:.4f}")
print(f"      Recall   : {rec:.4f}")
print(f"      F1 Score : {f1:.4f}")
print(f"      Confusion Matrix: {cm}")

print("[5/6] Serializing model...")
def export_tree_compact(tree):
    t = tree.tree_
    return {
        "f":  t.feature.tolist(),
        "th": [round(x, 6) for x in t.threshold.tolist()],
        "l":  t.children_left.tolist(),
        "r":  t.children_right.tolist(),
        "v":  [list(map(int, row[0])) for row in t.value]
    }

model_data = {
    "scaler_mean": [round(x, 8) for x in scaler.mean_.tolist()],
    "scaler_std":  [round(x, 8) for x in scaler.scale_.tolist()],
    "trees": [export_tree_compact(est) for est in rf.estimators_],
    "n_classes": 3,
    "metrics": {
        "accuracy":         round(acc, 4),
        "precision":        round(prec, 4),
        "recall":           round(rec, 4),
        "f1":               round(f1, 4),
        "confusion_matrix": cm
    },
    "aac_cols": aac_cols
}

model_json = json.dumps(model_data, separators=(",", ":"))
with open(OUTPUT_JSON, "w") as f:
    f.write(model_json)
print(f"      Saved {OUTPUT_JSON} ({len(model_json)/1024:.1f} KB)")

print("[6/6] Done!")
print()
print("─" * 60)
print("To update index.html with this new model:")
print("  1. Open index.html in a text editor")
print("  2. Find the line: const MODEL = {...")
print("  3. Replace everything between MODEL = and the semicolon")
print("     with the contents of model_compact.json")
print("─" * 60)
