# 🧠 Early Alzheimer's Detection System

AI-powered risk assessment using clinical biomarkers and protein sequence analysis.

---

## 📁 Project Structure

```
alzheimer_full_project/
│
├── index.html               ← Main web app (just open in browser — no server needed)
│
├── feature_extraction.py    ← Extract AAC features from FASTA sequences
├── train_model.py           ← Train Random Forest & export model JSON
├── evaluate_model.py        ← Evaluate model, generate plots, demo prediction
├── data_preprocessing.py    ← EDA, data quality checks, plots
├── batch_predict.py         ← Predict for a CSV/Excel batch of patients
├── retrain_model.py         ← Simplified all-in-one retraining script
├── utils.py                 ← Shared utilities (AAC, inference, validation)
│
├── requirements.txt         ← Python package dependencies
└── README.md                ← This file
```

---

## 🚀 Quick Start (Web App)

1. Extract the ZIP
2. Double-click **`index.html`** — opens in any browser
3. Fill in patient data and FASTA sequence
4. Click **Run Alzheimer's Risk Analysis**

**No command prompt. No server. No installation.**

---

## 🖥️ Web App Features

| Feature | Details |
|---|---|
| Inputs | Age, Glucose, BP, Memory Score, Cognitive Score, Sleep Quality, Protein FASTA |
| Prediction | Low / Medium / High risk |
| Probabilities | Animated bar chart for all 3 classes |
| Precautions | Specific recommendations for Medium and High risk |
| Metrics | Accuracy, Precision, Recall, F1 Score |
| Confusion Matrix | Color-coded table from test set |
| Sample sequences | APP protein, Amyloid Beta, Tau fragment |

---

## 🤖 ML Model Details

| Parameter | Value |
|---|---|
| Algorithm | Random Forest Classifier |
| Trees | 30 |
| Max Depth | 10 |
| Min Samples per Leaf | 5 |
| Training Samples | 826 (80%) |
| Test Samples | 208 (20%) |
| Total Features | 26 (6 clinical + 20 AAC) |
| Classes | 0=Low, 1=Medium, 2=High |

### Performance Metrics

| Metric | Score |
|---|---|
| Accuracy | ~85.5% |
| Precision | ~85.3% |
| Recall | ~85.5% |
| F1 Score | ~85.2% |

---

## 🧬 Protein Feature Extraction

Amino Acid Composition (AAC) is computed from the FASTA sequence:

    AAC[aa] = count(aa) / total_length

20 features are extracted — one per standard amino acid: A, C, D, E, F, G, H, I, K, L, M, N, P, Q, R, S, T, V, W, Y.

---

## 🐍 Python Scripts Usage

### 1. Install dependencies
    pip install -r requirements.txt

### 2. Extract features from FASTA dataset
    python feature_extraction.py
    # Input : combined_fasta_dataset.xlsx
    # Output: alzheimers_feature_dataset.xlsx

### 3. Train the model
    python train_model.py
    # Input : alzheimers_feature_dataset.xlsx
    # Output: model_compact.json, training_report.txt

### 4. Evaluate the model
    python evaluate_model.py
    # Output: evaluation_metrics.txt, confusion_matrix.png, feature_importance.png

### 5. Run EDA / preprocessing
    python data_preprocessing.py
    # Output: eda_report.txt, eda_plots.png

### 6. Batch predict on a CSV file
    python batch_predict.py --input patients.csv --output results.csv
    python batch_predict.py --demo

### 7. Retrain and update web app model
    python retrain_model.py
    # Then copy model_compact.json contents into index.html (see script output)

---

## 📊 Patient CSV Format (for batch_predict.py)

    PatientID,Age,Glucose,BloodPressure,MemoryScore,CognitiveScore,SleepQuality,Protein_Sequence
    P001,72,108,138,52,58,5.5,MLPGLALLLLAAWTARA...

---

## 🔧 Clinical Feature Ranges

| Feature | Range | Unit |
|---|---|---|
| Age | 40–100 | years |
| Glucose | 50–300 | mg/dL |
| Blood Pressure | 60–220 | mmHg |
| Memory Score | 0–100 | score |
| Cognitive Score | 0–100 | score |
| Sleep Quality | 2–12 | hrs/night |

---

## ⚠️ Disclaimer

This tool is for **research and educational purposes only**.
It is **not a medical diagnosis tool** and should not replace professional clinical evaluation.
Always consult a qualified neurologist or physician for medical advice.
