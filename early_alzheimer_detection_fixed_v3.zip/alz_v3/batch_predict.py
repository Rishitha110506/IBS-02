#!/usr/bin/env python3
"""
batch_predict.py
────────────────
Run predictions on a batch of patients from a CSV or Excel file.

Input CSV/Excel columns (required):
    Age, Glucose, BloodPressure, MemoryScore, CognitiveScore, SleepQuality, Protein_Sequence

Output: batch_results.csv  (adds columns: Prediction, Risk_Level, Prob_Low, Prob_Medium, Prob_High)

Usage:
    python batch_predict.py --input patients.csv
    python batch_predict.py --input patients.xlsx --output results.csv
    python batch_predict.py --demo   (generates and predicts 10 sample patients)
"""

import argparse
import os
import json
import numpy as np
import pandas as pd
import sys

# ─── IMPORT FROM UTILS ────────────────────────────────────────────────────────
try:
    from utils import fasta_to_aac, load_model, predict, validate_clinical, RISK_LABELS
except ImportError:
    # Inline fallback if utils.py not present
    AA_LIST = list("ACDEFGHIKLMNPQRSTVWY")
    RISK_LABELS = {0: "LOW", 1: "MEDIUM", 2: "HIGH"}

    def fasta_to_aac(seq):
        s = "".join(c for c in seq.upper() if c in AA_LIST)
        if not s: return None
        return [s.count(aa)/len(s) for aa in AA_LIST]

    def load_model(path="model_compact.json"):
        with open(path) as f: return json.load(f)

    def predict(model, features):
        x = [(v - model["scaler_mean"][i]) / model["scaler_std"][i] for i,v in enumerate(features)]
        probs = [0.0, 0.0, 0.0]
        for tree in model["trees"]:
            node = 0
            while True:
                if tree["f"][node] == -2:  # leaf node
                    v = tree["v"][node]; s = sum(v)
                    for c in range(3): probs[c] += v[c]/s
                    break
                node = tree["l"][node] if x[tree["f"][node]] <= tree["th"][node] else tree["r"][node]
        n = len(model["trees"])
        probs = [p/n for p in probs]
        pred = int(np.argmax(probs))
        return {"prediction": pred, "label": RISK_LABELS[pred],
                "probabilities": {"low": probs[0], "medium": probs[1], "high": probs[2]}}


# ─── DEMO DATA GENERATOR ─────────────────────────────────────────────────────
DEMO_SEQUENCES = [
    "MLPGLALLLLAAWTARALEVPTDGNAGLLAEPQIAMFCGRLNMHMN",   # APP fragment
    "KLVFFAEDVGSNKGAIIGLMVGGVVIATVIVI",                  # Amyloid beta
    "DAEFRHDSGYEVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA",        # Abeta variant
    "MQTAPVPMPDLKNVKSKIGSTENLKHQPGGKVQIINKK",            # Tau fragment
    "ACDEFGHIKLMNPQRSTVWYACDEFGHIKLMNPQRSTVWY",          # Balanced sequence
    "AAAAAAAAAAAAAAAAAAAAAA",                             # Alanine-rich (non-typical)
    "MLPGLALLLLAAWTARA",                                  # Short APP signal
    "EVHHQKLVFFAEDVGSNKGAIIGLMVGGVVIA",                  # Core amyloid
    "HDSGYEVHHQKLVFFAEDVGSNKGAII",                       # Abeta core
    "ACDEFGHIKLMNPQRSTVWYMNPQRSTVWY",                    # Mixed
]

def generate_demo_data():
    np.random.seed(99)
    n = 10
    rows = []
    for i in range(n):
        risk_level = np.random.choice([0, 1, 2])
        if risk_level == 0:    # low
            age, glucose, bp = np.random.randint(45, 65), np.random.randint(80, 100), np.random.randint(110, 125)
            memory, cognitive, sleep = np.random.randint(75, 95), np.random.randint(78, 95), round(np.random.uniform(7.0, 8.5), 1)
        elif risk_level == 1:  # medium
            age, glucose, bp = np.random.randint(65, 75), np.random.randint(100, 115), np.random.randint(125, 140)
            memory, cognitive, sleep = np.random.randint(55, 75), np.random.randint(58, 75), round(np.random.uniform(5.5, 7.0), 1)
        else:                  # high
            age, glucose, bp = np.random.randint(75, 92), np.random.randint(115, 160), np.random.randint(140, 175)
            memory, cognitive, sleep = np.random.randint(30, 55), np.random.randint(35, 58), round(np.random.uniform(3.5, 5.5), 1)

        rows.append({
            "PatientID":        f"P{i+1:03d}",
            "Age":              age,
            "Glucose":          glucose,
            "BloodPressure":    bp,
            "MemoryScore":      memory,
            "CognitiveScore":   cognitive,
            "SleepQuality":     sleep,
            "Protein_Sequence": DEMO_SEQUENCES[i % len(DEMO_SEQUENCES)],
        })
    return pd.DataFrame(rows)


# ─── BATCH PREDICTION ─────────────────────────────────────────────────────────
def run_batch(df: pd.DataFrame, model: dict) -> pd.DataFrame:
    required_cols = ["Age","Glucose","BloodPressure","MemoryScore","CognitiveScore","SleepQuality","Protein_Sequence"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    results = []
    errors  = []

    for idx, row in df.iterrows():
        try:
            aac = fasta_to_aac(str(row["Protein_Sequence"]))
            if aac is None:
                errors.append(f"Row {idx}: invalid/empty protein sequence")
                results.append({"Prediction": -1, "Risk_Level": "ERROR",
                                 "Prob_Low": None, "Prob_Medium": None, "Prob_High": None})
                continue

            features = [
                float(row["Age"]), float(row["Glucose"]), float(row["BloodPressure"]),
                float(row["MemoryScore"]), float(row["CognitiveScore"]), float(row["SleepQuality"])
            ] + aac

            result = predict(model, features)
            p = result["probabilities"]
            results.append({
                "Prediction":  result["prediction"],
                "Risk_Level":  result["label"],
                "Prob_Low":    round(p["low"],    4),
                "Prob_Medium": round(p["medium"], 4),
                "Prob_High":   round(p["high"],   4),
            })
        except Exception as e:
            errors.append(f"Row {idx}: {e}")
            results.append({"Prediction": -1, "Risk_Level": "ERROR",
                             "Prob_Low": None, "Prob_Medium": None, "Prob_High": None})

    results_df = pd.DataFrame(results)
    out_df = pd.concat([df.reset_index(drop=True), results_df], axis=1)

    if errors:
        print(f"\n⚠ {len(errors)} rows had errors:")
        for e in errors[:5]:
            print(f"   {e}")

    return out_df


# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Batch Alzheimer's risk prediction")
    parser.add_argument("--input",  type=str, help="Input CSV or Excel file")
    parser.add_argument("--output", type=str, default="batch_results.csv", help="Output CSV file")
    parser.add_argument("--model",  type=str, default="model_compact.json", help="Model JSON path")
    parser.add_argument("--demo",   action="store_true", help="Run with 10 generated demo patients")
    args = parser.parse_args()

    if not args.demo and not args.input:
        parser.print_help()
        print("\nTip: Use --demo to test with 10 generated patients.")
        sys.exit(1)

    # Load model
    if not os.path.exists(args.model):
        print(f"ERROR: Model file not found: {args.model}")
        print("Run train_model.py first.")
        sys.exit(1)
    model = load_model(args.model)
    print(f"✔ Model loaded ({len(model['trees'])} trees)")

    # Load input
    if args.demo:
        print("Generating demo patient data...")
        df = generate_demo_data()
        print(f"  {len(df)} demo patients created")
    else:
        print(f"Loading input: {args.input}")
        if args.input.endswith(".xlsx") or args.input.endswith(".xls"):
            df = pd.read_excel(args.input)
        else:
            df = pd.read_csv(args.input)
        print(f"  {len(df)} rows loaded")

    # Run predictions
    print("Running predictions...")
    results = run_batch(df, model)

    # Summary
    valid = results[results["Risk_Level"] != "ERROR"]
    if len(valid) > 0:
        dist = valid["Risk_Level"].value_counts()
        print(f"\n  Risk distribution:")
        for level in ["LOW", "MEDIUM", "HIGH"]:
            count = dist.get(level, 0)
            pct = count / len(valid) * 100
            print(f"    {level:6s}: {count:3d} ({pct:.1f}%)")

    # Save
    results.to_csv(args.output, index=False)
    print(f"\n✅ Results saved to: {args.output}")


if __name__ == "__main__":
    main()
